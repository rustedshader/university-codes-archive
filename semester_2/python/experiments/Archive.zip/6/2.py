print('Enter n')
n: int = int(input())
x = tuple(i for i in range(n+1))
print(x)
    