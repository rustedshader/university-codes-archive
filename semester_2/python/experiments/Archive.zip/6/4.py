# TODO Have to do
hmap = {}
for _ in range(int(input("Enter Number of Values to add: "))):
    hmap[input()] = input()

print(hmap.keys())
print(hmap.values())
