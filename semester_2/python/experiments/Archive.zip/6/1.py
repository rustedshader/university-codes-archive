l = [1,2,3,4,5,6,2,3,2,1,3,4]
s = sum([l.count(i) for i in range(4)])
print(s)