print('Enter the string')
count:int = 0
for i in input():
    if i.isupper():
        count+=1
print(count)