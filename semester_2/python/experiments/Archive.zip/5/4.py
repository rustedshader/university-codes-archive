print('Enter string and substring')
s,sb = map(str,input().split(" "))
print(s.count(sb))