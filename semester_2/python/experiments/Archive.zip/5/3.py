print('Enter the sentence')
print(input().replace(' ','\n'))