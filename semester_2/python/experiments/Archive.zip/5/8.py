s1 = set(['Red', 'Yellow', 'Orange', 'Blue'])
s2 = set(['Violet', 'Blue', 'Purple' ])
print(s1,s2)