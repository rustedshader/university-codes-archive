print('Enter the sentence')
s = input().split()
print(set(s))